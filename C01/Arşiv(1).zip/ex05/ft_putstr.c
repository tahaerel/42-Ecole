#include <unistd.h>

void	ft_putstr(char *str)
{
	char	*charptr;

	charptr = str;
	while (*charptr != 0)
	{
		write(1, charptr, 1);
		charptr++;
	}
}
